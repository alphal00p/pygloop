#!/usr/bin/env python3
"""Run one campaign card and write a compact machine-readable result."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from numbers import Integral, Real
from pathlib import Path
import sys
from typing import Any


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
sys.path.insert(0, str(ROOT / "src"))

import pygloop  # noqa: E402


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _json_value(value: Any, *, depth: int = 0) -> Any:
    if depth > 8:
        raise TypeError
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, Integral):
        return int(value)
    if isinstance(value, Real):
        converted = float(value)
        if not math.isfinite(converted):
            raise TypeError
        return converted
    if isinstance(value, complex):
        if value.imag != 0.0:
            return {"real": value.real, "imag": value.imag}
        return value.real
    if isinstance(value, (list, tuple)):
        converted_items = []
        for item in value:
            try:
                converted_items.append(_json_value(item, depth=depth + 1))
            except TypeError:
                continue
        return converted_items
    if isinstance(value, dict):
        converted_mapping = {}
        for key, item in value.items():
            try:
                converted_mapping[str(key)] = _json_value(
                    item, depth=depth + 1
                )
            except TypeError:
                continue
        return converted_mapping
    if hasattr(value, "__dict__"):
        converted_object = {"__class__": type(value).__name__}
        for name, item in vars(value).items():
            try:
                converted_object[str(name)] = _json_value(
                    item, depth=depth + 1
                )
            except TypeError:
                continue
        return converted_object
    raise TypeError


def _integration_payload(integration_result: Any) -> dict[str, Any]:
    selected: dict[str, Any] = {}
    always = {
        "central_value",
        "error",
        "n_samples",
        "elapsed_time",
        "max_wgt",
        "max_wgt_no_jacobian",
        "max_wgt_before_clipping",
    }
    diagnostic_prefixes = (
        "dy_",
        "physical_channel_",
        "graph_channel_",
        "q_bin_",
        "rotation_",
        "large_weight_",
        "stability_",
        "t_solver_",
        "soft_mirror_",
        "nan_weight_",
        "nonfinite_",
        "iteration_",
    )
    for name, value in vars(integration_result).items():
        if name not in always and not name.startswith(diagnostic_prefixes):
            continue
        try:
            selected[name] = _json_value(value)
        except TypeError:
            continue
    selected.setdefault("central_value", float(integration_result.central_value))
    selected.setdefault("error", float(integration_result.error))
    return selected


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--card", type=Path, required=True)
    parser.add_argument("--result", type=Path, required=True)
    parser.add_argument("--iterations", type=int)
    parser.add_argument("--points-per-iteration", type=int)
    parser.add_argument("--cores", type=int)
    parser.add_argument("--seed", type=int)
    args = parser.parse_args()

    card = args.card.expanduser().resolve()
    result_path = args.result.expanduser().resolve()
    if not card.is_file():
        parser.error(f"card does not exist: {card}")

    command = ["--dy-card", str(card), "integrate"]
    if args.iterations is not None:
        command.extend(("--n_iterations", str(args.iterations)))
    if args.points_per_iteration is not None:
        command.extend(
            ("--points_per_iteration", str(args.points_per_iteration))
        )
    if args.cores is not None:
        command.extend(("--n_cores", str(args.cores)))
    if args.seed is not None:
        command.extend(("--seed", str(args.seed)))
    result = pygloop.main(command)
    if not isinstance(result, dict) or "integration_result" not in result:
        raise RuntimeError("pygloop did not return an integration result")
    payload = {
        "schema_version": 1,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "card": str(card.relative_to(ROOT)),
        "card_sha256": _sha256(card),
        "execution_overrides": {
            "iterations": args.iterations,
            "points_per_iteration": args.points_per_iteration,
            "cores": args.cores,
            "seed": args.seed,
        },
        "integration_time_s": float(result.get("integration_time_s", 0.0)),
        "integration_result": _integration_payload(result["integration_result"]),
    }
    if "dy_physical_channels" in result:
        payload["dy_physical_channels"] = _json_value(
            result["dy_physical_channels"]
        )
    if "dy_effective_settings" in result:
        payload["dy_effective_settings"] = _json_value(
            result["dy_effective_settings"]
        )
    result_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = result_path.with_suffix(result_path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, sort_keys=True, allow_nan=False) + "\n",
        encoding="utf-8",
    )
    temporary.replace(result_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
